# World Cup 2026 — Betting Strategy Conversation (Full Transcript / Handoff)

> Context handoff for a new Cowork chat. Captures the full thread: match reads, odds, the
> betting-portfolio strategy, day-by-day settlements, and the final allocations.
> **All odds are Bet365 decimal prices via KickOff unless noted — NOT Hard Rock Bet's live
> board.** Everything here is a probability/strategy illustration, not betting advice.

Dates: today = **Saturday, June 20, 2026**. "Yesterday" = **Friday, June 19, 2026**.
User location: Satellite Beach, FL (Hard Rock Bet is the de facto FL mobile sportsbook).

---

## 1. Early match reads

**Mexico vs South Korea (Thu, played):** Mexico modest favorites (~-125 / 1.80). Lean: narrow
Mexico win (1-0 / 2-1), draw a live possibility since both could play safe.

**USA vs Australia (preview):** USA favorites (~-159 / 1.60). Lean: USA win 2-1/2-0; Australia
compact and physical; Pulisic calf doubt.

---

## 2. Friday June 19 — original prediction table (decimal odds)

| Match | Outcome | Likely scores | Win odds (dec) |
|-------|---------|---------------|----------------|
| USA vs Australia | USA win | 2-1 / 2-0 | USA 1.60 · Draw 4.33 · AUS 5.00 |
| Scotland vs Morocco | Morocco win | 2-0 / 1-0 | MAR 1.70 · Draw 3.60 · SCO 5.25 |
| Turkey vs Paraguay | Turkey win | 2-1 / 1-0 | TUR 2.00 · Draw 3.25 · PAR 4.00 |
| Brazil vs Haiti | Brazil win | 3-0 / 4-0 | BRA 1.09 · Draw ~13 · HAI ~26 |

Correct-score odds used later (Bet365 dec):
- USA: 1-0 6.50 · 2-0 7.50 · 2-1 9.00 · 3-0 12.0
- Morocco: 1-0 6.00 · 2-0 7.50 · 2-1 9.50 · 3-0 13.0
- Turkey/Paraguay: Draw 1-1 6.50 · TUR 1-0 7.00 · Draw 0-0 8.00 · TUR 2-1 9.50 · PAR 1-0 11.0
- Brazil: 2-0 7.50 · 3-0 7.00 · 4-0 8.50 · 1-0 11.0

**Note on Hard Rock Bet:** their live moneyline / correct-score / double-chance board is not
retrievable via web search, so all quoted prices are Bet365 consensus (cross-checked where
possible, e.g. RotoWire had NED -138 ≈ 1.72). Verify exact prices in the Hard Rock app.

---

## 3. Saturday June 20 — today's games

Three games (ET): **Netherlands vs Sweden 1 PM**, **Germany vs Côte d'Ivoire 4 PM**,
**Ecuador vs Curaçao 8 PM**.

Initial reads (decimal odds, top-2 scores):

| Match | Lean | Win odds | Top-2 scores |
|-------|------|----------|--------------|
| Netherlands vs Sweden | NED (low conf ~55%) | 1.73 · D 4.00 · SWE 4.33 | NED 1-0 8.50 / NED 2-1 9.00 |
| Germany vs Côte d'Ivoire | GER (~64%) | 1.50 · D 4.50 · CIV 5.75 | GER 2-1 8.50 / 2-0 9.00 |
| Ecuador vs Curaçao | ECU (~86%) | 1.13 · D 9.00 · CUW 19.0 | ECU 2-0 5.50 / 3-0 6.00 |

Key nuance: the model's single most-likely result in NED/SWE is a **1-1 draw** — it's a coin
flip, not a clean favorite.

---

## 4. Friday results vs predictions + self-critique

Actual results:
- **USA 2-0 Australia** — predicted USA win 2-1/2-0 → outcome ✅, score ✅ (2-0)
- **Scotland 0-1 Morocco** — predicted MAR win 2-0/1-0 → outcome ✅, score ✅ (1-0)
- **Brazil 3-0 Haiti** — predicted BRA win 3-0/4-0 → outcome ✅, score ✅ (3-0)
- **Turkey 0-1 Paraguay** — predicted TUR win → outcome ❌ (the upset)

3 of 4 outcomes correct; the miss was the coin flip.

**Process lessons identified:**
1. Called a game (Turkey/Paraguay) my own data flagged as a coin flip — pick'em moneyline,
   model's top result was a 1-1 draw, Turkey had ~30 shots but 0 goals vs Australia.
   The table format stripped out the uncertainty I'd noted in prose.
2. Over-relied on the betting-market consensus instead of independent signals (xG, finishing,
   tactics, lineup news).
3. Credited a phantom home advantage to Turkey at a neutral US venue.
4. The 3 "hits" were largely chalk; correct-score skill is best tested on the close game,
   where the method gave no edge.

Fixes: keep a confidence column in every table; separate "most likely team to win" from
"most likely single result"; weight underlying performance over the moneyline on near-pick'em
games.

---

## 5. What Friday's table *should* have been (improved process)

| Match | Most likely single result | Win lean + conf | Top-2 scores | Signal weighted |
|-------|---------------------------|-----------------|--------------|-----------------|
| USA vs Australia | USA narrow win | USA ~59% | USA 1-0 / 2-0 | USA only 1.42 xG in their 4-1 → controlled win |
| Scotland vs Morocco | Morocco 1-0 | MAR ~57% | MAR 1-0 / 2-0 | Elite Morocco defense → lowest-scoring game |
| Turkey vs Paraguay | **1-1 draw (coin flip)** | TUR ~45% (low) | Draw 1-1 / TUR 1-0 | Pick'em; Turkey finishing crisis; Paraguay live ~25% |
| Brazil vs Haiti | Brazil 2-0 / 3-0 | BRA ~87% | BRA 2-0 / 3-0 | Tempered from 4-0 (Brazil drew opener 1-1) |

The gain is calibration, not a 4th correct call: it would have told you *don't trust* Turkey/Paraguay.

---

## 6. Today's table, improved process (with confidence + draw-vs-win split)

- **Netherlands vs Sweden (1 PM):** single most likely = **1-1 draw**; NED lean LOW (~55%).
  Sweden in better form (5-1 vs Tunisia, +4 GD). Today's trap game.
- **Germany vs Côte d'Ivoire (4 PM):** Germany win, Moderate-High (~64%). 7-1 opener flatters
  them (vs Curaçao); CIV won 1-0 and can sit deep.
- **Ecuador vs Curaçao (8 PM):** Ecuador win, Very High (~86%) but a low-scoring side — a tight
  1-0/2-0 more likely than a rout.

---

## 7. Double chance (1N / N2) for the coin flip

Only Netherlands/Sweden warrants it (the other two favorites are too short).
- **1N (NED or draw) ≈ 1.20** — safe, loses only on a Sweden win.
- **N2 (draw or SWE) ≈ 2.05** — the value play if you believe the Dutch are overpriced; wins on
  a draw or a Sweden win, loses only if Netherlands win.

---

## 8. The betting-portfolio strategy ("banker + savers") — full detail

The approach used throughout is a **core-and-satellite (a.k.a. "banker + savers") portfolio**:
the bulk stake goes on a high-probability / low-yield market (moneyline win, or a double chance),
and small stakes ride high-yield longshots (correct scores) in the *same* game.

### 8.1 Building blocks (each with its source)

**Value betting / Expected Value (EV)** — *source: Mr-Tips.*
Only stake where your estimated probability beats the odds' implied probability.
- Implied probability of decimal odds `O` = `1 / O`.
- EV of a stake `S` at odds `O` with your true win probability `p`:
  `EV = p × (O − 1) × S − (1 − p) × S`.
- Worked example from the source: a 58% true win probability against odds of **1.85**
  (≈54% implied) is positive-EV. Decimal→American: `+ (O−1)×100` if O ≥ 2, else `−100/(O−1)`.

**Double chance as insurance** — *source: FOX Sports (Betting).*
Covers two of the three outcomes (1X / 12 / X2, written here as 1N / 12 / N2 with N = draw).
Pays less than the moneyline but with materially lower risk; best when you're confident one
specific team **won't** win. Used as the coin-flip core (N2 = draw-or-underdog when the favorite
looks overpriced; 1N = favorite-or-draw as pure insurance).

**Dutching / "score casting"** — *source: ChampLeagueBet.*
Back several scorelines at once; lower combined odds but higher hit rate, with stakes distributed
to optimise/equalise returns. Same source's warning: a single correct-score pick **loses ~7 times
out of 8** even when the general read is right — which is exactly why scores are *satellites*,
never the core.

**Correct score works best in combination, not alone** — *source: gammastack.*
Most viable bundled into combo markets or hedged (e.g. with BTTS-No), reinforcing small-stake
treatment.

**Same-game combination / narrative building** — *source: sportsmemo.*
Stacking correlated props (result + score + BTTS) tells one "story" of the match but compounds
the margin and lowers combined odds.

**Bankroll discipline** — *sources: Mr-Tips, mytopsportsbooks.*
Flat-stake ~1% of a bankroll on value spots; track every wager; value small frequent wins rather
than basing everything on longshots.

**Kelly criterion (sizing, referenced conceptually)** — classic staking formula:
`fraction of bankroll = edge / odds = (p × (O − 1) − (1 − p)) / (O − 1)`. Fractional Kelly
(½ or ¼) is the common practical hedge against model error. The $10/$20 flat caps used in this
thread are a simplification of this.

### 8.2 Structure varies by the game's odds shape
- **Coin flip →** double-chance core + small score savers, **or skip entirely** (the most
  valuable single discipline — see the Friday settlements).
- **Clear favorite →** moneyline core + the 1-2 most-likely scores.
- **Near-lock, short core →** small banker + dutch the likely scores (the core returns little,
  so weight shifts to scores).

### 8.3 Refinements added during the thread
- **Skip the genuine tossup** (Friday's Turkey/Paraguay loss proved it).
- **Trim lottery savers** — long-odds scores were dead money; concentrate on the anchor (single
  most-likely momentum-implied score).
- **Plug the "unlisted-score bleed"** — a favorite winning by a score you didn't list quietly
  kills the savers; cover the next-most-likely scores.
- **Tournament momentum** from openers is non-negligible and partly priced in — use it to tilt
  which scores get the heaviest saver, and to flag overpriced favorites.
- **Account for the underdog scoring** (the Curaçao catch) — don't zero out BTTS-Yes outcomes.

### 8.4 Standing caveat
The vig is in every price (correct-score carries the fattest margin), so this manages
**variance and hit-rate**, it does **not** manufacture an edge. The only durable, repeatable
gain demonstrated was the discipline to skip a true coin flip.

---

## 9. Friday settled — ORIGINAL plan (flat $20/game, all four)

| Game (final) | Core/Banker | Savers (stake → result) | Returned |
|--------------|-------------|--------------------------|----------|
| USA 2-0 | USA win 1.60 $10 ✅ $16 | 1-0 $4 ✗ · **2-0 $3 ✅ $22.50** · 2-1 $2 ✗ · 3-0 $1 ✗ | $38.50 |
| MAR 1-0 | MAR win 1.70 $10 ✅ $17 | **1-0 $4 ✅ $24** · 2-0 $3 ✗ · 2-1 $2 ✗ · 3-0 $1 ✗ | $41.00 |
| PAR 1-0 | 1N (TUR or draw) 1.20 $10 ✗ | Draw1-1 $4 ✗ · TUR1-0 $3 ✗ · Draw0-0 $2 ✗ · TUR2-1 $1 ✗ | $0.00 |
| BRA 3-0 | BRA win 1.10 $10 ✅ $11 | 2-0 $4 ✗ · **3-0 $3 ✅ $21** · 4-0 $2 ✗ · 1-0 $1 ✗ | $32.00 |

**Staked $80 → returned $111.50 → net +$31.50.** The full $20 on the Turkey/Paraguay coin flip
was lost.

---

## 10. Friday settled — REVISED complete strategy (momentum + skip coin flip)

Opener momentum: Sweden 5-1, Germany 7-1 (vs minnow), CIV 1-0 (clean sheet), Ecuador lost 0-1,
USA 4-1 (xG-flattered), Australia 2-0 (outshot 30-9). For Friday: USA/Australia both confident
(controlled win), Morocco defensively elite, Turkey can't finish / Paraguay can score (don't
back Turkey), Brazil off-color but responding.

| Game (final) | Bets (stake → result) | Returned | Net |
|--------------|------------------------|----------|-----|
| USA 2-0 | Core USA 1.60 $8 ✅ $12.80 · **2-0 $4 ✅ $30** · 1-0 $3 ✗ · 2-1 $2 ✗ | $42.80 | +$25.80 |
| MAR 1-0 | Core MAR 1.70 $8 ✅ $13.60 · **1-0 $5 ✅ $30** · 2-0 $3 ✗ · 2-1 $1 ✗ | $43.60 | +$26.60 |
| PAR 1-0 | **SKIP** (optional token N2 draw-or-PAR 1.70 $5 ✅ $8.50) | $0 / $8.50 | $0 / +$3.50 |
| BRA 3-0 | Banker BRA 1.10 $8 ✅ $8.80 · 2-0 $4 ✗ · **3-0 $4 ✅ $28** · 1-0 $1 ✗ | $36.80 | +$19.80 |

**Staked $51 → returned $123.20 → net +$72.20** (+$75.70 with the optional token).

**Skill vs luck:** the repeatable gain was *skipping the coin flip* (swung the day by $20 vs
backing it). Going 3-for-3 on the anchor savers was favorable variance — a typical day, one
misses and the total drops toward +$35–45.

---

## 11. Curaçao-can-score correction (user catch)

Original Ecuador savers were all Ecuador clean sheets (1-0/2-0/3-0), implicitly 0% for Curaçao
scoring — but Curaçao scored on Germany. BTTS-No is favored (~67%) because Ecuador's defense is
elite, so clean sheets stay the lean, but ~33% (≈1-in-3) chance Curaçao scores had zero coverage.
Fix: added **ECU 2-1 @ 13.0** (Curaçao scores) and trimmed the 3-0 stake. Residual tail noted:
if Curaçao scores and Ecuador manages only one, a 1-1 draw kills the banker too.

---

## 12. Today — momentum-revised reads

- **Netherlands vs Sweden:** momentum favors Sweden; Dutch are a weak favorite → **SKIP** (or
  small N2 token). Strengthens the "don't back the Dutch" thesis.
- **Germany vs CIV:** competitive Germany win, not a rout; CIV can score → cover 2-1, 2-0, 1-0.
- **Ecuador vs Curaçao:** Ecuador just got *shut out* — wounded, must-win, low-scoring →
  load 1-0; blowout unlikely; keep ECU 2-1 for a Curaçao goal.

---

## 13. FINAL today plan (base ~$34)

| Game (ET) | Bet | Odds | Stake | If it hits |
|-----------|-----|------|-------|------------|
| Netherlands vs Sweden 1 PM | **SKIP** (optional N2 draw-or-SWE) | (2.05) | $0 (opt $5) | ($10.25) |
| Germany vs Côte d'Ivoire 4 PM | Core: Germany win | 1.50 | $8 | $12.00 |
| | GER 2-0 | 9.00 | $3 | $27.00 |
| | GER 2-1 (CIV scores) | 8.50 | $3 | $25.50 |
| | GER 1-0 (CIV defends) | 9.50 | $2 | $19.00 |
| Ecuador vs Curaçao 8 PM | Banker: Ecuador win | 1.13 | $6 | $6.78 |
| | ECU 1-0 (anchor) | 7.50 | $5 | $37.50 |
| | ECU 2-0 | 5.50 | $4 | $22.00 |
| | ECU 2-1 (Curaçao scores) | 13.0 | $2 | $26.00 |
| | ECU 3-0 (flier) | 6.00 | $1 | $6.00 |

**Exposure: $34** (Germany $16 + Ecuador $18, Netherlands skipped); $39 with the optional token.

---

## 14. DOUBLED today plan (~$68) — allocation, not just ×2

Principle: double the conviction, not the action. **Netherlands stays skipped** — doubling does
not justify backing the coin flip. Extra money loads the anchor savers, only modestly lifts the
short cores, and adds a couple of probable scores to plug the "wins by an unlisted score" bleed.

**Germany vs CIV — $32:** Core GER win 1.50 **$10** ($15.00) · GER 2-0 9.00 **$7** ($63) ·
GER 2-1 8.50 **$6** ($51) · GER 1-0 9.50 **$5** ($47.50) · GER 3-0 ~12.0 **$2** ($24) ·
GER 3-1 ~14.0 **$2** ($28).

**Ecuador vs Curaçao — $36:** Banker ECU win 1.13 **$10** ($11.30) · ECU 1-0 7.50 **$9** ($67.50) ·
ECU 2-0 5.50 **$8** ($44) · ECU 2-1 13.0 **$4** ($52) · ECU 3-0 6.00 **$3** ($18) ·
ECU 1-1 draw ~17.0 **$2** ($34, tail hedge).

**Netherlands:** $0 (optional token kept at ~$5, deliberately not doubled).

Simpler alternative: just 2× every existing stake (Germany $32, Ecuador $36) — same risk shape.
Caveat: doubling the stake doubles the swing both ways and doubles what the margin costs over
time; it amplifies, it doesn't improve the odds.

---

## 15. Artifacts produced (PDFs)

- `today-betting-plan-2026-06-20.pdf` — today's plan, grouped by game.
- `yesterday-betting-report-2026-06-19.pdf` — Friday settled, revised strategy (+$72.20 / $51).
- `yesterday-original-bets-2026-06-19.pdf` — Friday settled, original plan (+$31.50 / $80).

---

## 16. Open follow-ups

- Settle today's plan against results once all three games finish (produce the matching settled
  PDF so there's a full pair for Saturday).
- If exact Hard Rock Bet prices are wanted, pull them in-app and compare against the Bet365 lines
  used here.

---

### Standing caveats (apply to everything above)
- Odds are Bet365 decimal via KickOff, not Hard Rock's live board; correct-score odds beyond the
  main lines are approximate.
- The bookmaker margin is in every price; this manages variance, not edge. Each correct-score
  saver is a sub-15% shot.
- This is a probability/strategy exercise, **not** betting advice. Never stake more than you'd be
  fine losing.

---

## 17. Sources & research used

> These are the publishers/tools the analysis drew on. KickOff URLs were fetched directly and are
> exact; other entries are by publisher (exact article URLs are re-retrievable by searching the
> match name + "prediction"/"odds"). Live odds shift, so re-verify before relying on any figure.

### Match data, odds, model probabilities, correct-score grids
- **KickOff** (`kickoff.co.uk`) — primary source for model win-%, predicted scorelines, recent
  form, BTTS/double-chance reads, and Bet365 decimal prices. Pages fetched:
  - `/world-cup-predictions-stats-odds/usa-vs-australia/`
  - `/world-cup-predictions-stats-odds/scotland-vs-morocco/`
  - `/world-cup-predictions-stats-odds/brazil-vs-haiti/`
  - `/world-cup-predictions-stats-odds/turkey-vs-paraguay/`
  - `/world-cup-predictions-stats-odds/netherlands-vs-sweden/`
  - `/world-cup-predictions-stats-odds/germany-vs-cote-d-ivoire/`
  - `/world-cup-predictions-stats-odds/ecuador-vs-curacao/`
- **FOX Sports** — match previews and analyst predictions; the low-scoring / double-chance framing
  (Mexico/South Korea, USA/Australia).
- **RotoWire** — Netherlands/Sweden moneyline (NED −138 ≈ 1.72) and form note; cross-check on the
  consensus line.
- **Sports Illustrated (SI)**, **Racing Post** — preview and odds context (e.g. Scotland/Morocco,
  Morocco's qualifying defensive record).
- **Odds aggregators surfaced in search** — DraftKings, FanDuel, BetMGM, Caesars (consensus
  moneylines). *Hard Rock Bet's live board was not retrievable via search.*
- **NBC Sports / Yahoo Sports** — fixture schedule and kickoff times (ET).
- **Sports-data tool (SportRadar feed)** — actual final scores and live win probabilities used to
  settle bets: USA 2-0 AUS, Scotland 0-1 Morocco, Brazil 3-0 Haiti, Turkey 0-1 Paraguay; and the
  group/standings + opener results that fed the momentum reads.

### Betting-strategy research
- **Mr-Tips** — value betting, the EV formula, ~1% bankroll flat staking, wager tracking.
- **gammastack** — correct-score markets best used in combination / hedged.
- **FOX Sports (Betting)** — double chance covering two of three outcomes (insurance use).
- **ChampLeagueBet** — dutching / "score casting"; single correct-score loses ~7 of 8.
- **mytopsportsbooks** — valuing small frequent wins over longshots.
- **sportsmemo** — same-game combination / narrative-building props and their margin cost.
- **Kelly criterion** — standard staking-size formula (referenced conceptually, not from a single
  cited page).

### Method notes
- Where exact prices couldn't be sourced (Hard Rock board; some deep correct-score lines and the
  Turkey/Paraguay double-chance price), figures are **Bet365 consensus or estimated from the
  three-way line**, and flagged as such in-text.
- Decimal↔implied: `implied % = 1 / decimal`. Double-chance fair odds ≈
  `1 / (1/O_a + 1/O_b)` before margin.
